module.exports = {
name:"test",
aliases:["test1","test2","test3"],
code:`
Hola todo funcionando por el momento! <@$authorID>`
}
